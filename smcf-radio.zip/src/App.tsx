import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Home,
  User,
  Shield,
  Play,
  Pause,
  Headphones,
  Award,
} from 'lucide-react';
import { STREAM_URL, SCHEDULE, RJS, PROGRAMS } from './data';
import { Program } from './types';
import { TunerStrip } from './components/TunerStrip';
import { CampusTicker } from './components/CampusTicker';
import { ProgramCard } from './components/ProgramCard';
import { StudentPortal } from './components/StudentPortal';
import { AdminConsole } from './components/AdminConsole';
import { NowPlayingBar } from './components/NowPlayingBar';

export default function App() {
  const [tab, setTab] = useState<'home' | 'portal' | 'admin'>('home');
  const [isLive, setIsLive] = useState(true);
  const [nowPlaying, setNowPlaying] = useState({
    title: 'Aaj Ke Mehmaan — A Meet & Greet',
    rj: 'RJ Priya',
  });
  const [playing, setPlaying] = useState(false);
  const [listeners, setListeners] = useState(214);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Synchronize playback state with native audio tag
  useEffect(() => {
    if (!audioRef.current) return;
    if (playing) {
      audioRef.current.play().catch((err) => {
        console.warn('Audio play failed:', err);
      });
    } else {
      audioRef.current.pause();
    }
  }, [playing]);

  // Simulate active listener variance on interval when live
  useEffect(() => {
    if (!isLive) return;
    const interval = setInterval(() => {
      setListeners((l) =>
        Math.max(120, l + Math.round((Math.random() - 0.45) * 8))
      );
    }, 3000);
    return () => clearInterval(interval);
  }, [isLive]);

  const handlePlayProgram = (program: Program) => {
    setNowPlaying({ title: program.title, rj: program.rj });
    setPlaying(true);
  };

  const navItems = [
    { key: 'home', label: 'Home', icon: Home },
    { key: 'portal', label: 'Student Portal', icon: User },
    { key: 'admin', label: 'Admin Console', icon: Shield },
  ] as const;

  return (
    <div className="min-h-screen text-slate-900 bg-white selection:bg-indigo-500/25 selection:text-indigo-950">
      {/* Hidden Audio Player */}
      <audio ref={audioRef} src={STREAM_URL} preload="none" />

      {/* Main Navigation Header */}
      <header
        className="sticky top-0 z-40 backdrop-blur-md border-b transition-all duration-200"
        style={{
          background: 'rgba(15, 23, 42, 0.95)',
          borderColor: 'rgba(99, 102, 241, 0.15)',
        }}
      >
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <button
            onClick={() => setTab('home')}
            className="flex items-center gap-3 group focus:outline-none focus-visible:ring-2 focus-visible:ring-lime"
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center font-display font-extrabold text-lg transition-transform group-hover:scale-105 active:scale-95"
              style={{ background: 'var(--lime)', color: 'var(--navy-deep)' }}
            >
              S
            </div>
            <div className="text-left leading-none">
              <div className="font-display font-bold text-white text-[16px] tracking-tight">
                SMCF Radio
              </div>
              <div
                className="text-[11px] font-medium mt-1 leading-normal flex flex-col"
                style={{ color: 'var(--lime)' }}
              >
                <div className="font-hi">आपकी आवाज़, आपका रेडियो</div>
                <div className="font-display">Aapki Awaaz, Aapka Radio</div>
              </div>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1.5">
            {navItems.map((item) => {
              const isActive = tab === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => setTab(item.key)}
                  className="px-5 py-2 rounded-full text-xs font-bold tracking-wide transition-all uppercase focus:outline-none"
                  style={{
                    color: isActive ? 'var(--navy-deep)' : 'rgba(255, 255, 255, 0.75)',
                    background: isActive ? 'var(--lime)' : 'transparent',
                  }}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Mobile Navigation */}
          <div className="flex md:hidden gap-1.5">
            {navItems.map((item) => {
              const isActive = tab === item.key;
              const IconComponent = item.icon;
              return (
                <button
                  key={item.key}
                  onClick={() => setTab(item.key)}
                  className="w-9 h-9 rounded-full flex items-center justify-center transition-all focus:outline-none"
                  style={{
                    background: isActive ? 'var(--lime)' : 'rgba(255, 255, 255, 0.1)',
                    color: isActive ? 'var(--navy-deep)' : '#fff',
                  }}
                  title={item.label}
                >
                  <IconComponent className="w-4 h-4" />
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Container Pages */}
      <main className="relative">
        <AnimatePresence mode="wait">
          {tab === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
            >
              {/* Hero Banner Section */}
              <section
                className="relative overflow-hidden"
                style={{
                  background:
                    'linear-gradient(160deg, var(--navy-deep) 0%, var(--navy) 55%, var(--forest) 130%)',
                }}
              >
                <div className="grain absolute inset-0 opacity-30 pointer-events-none" />
                <div className="max-w-6xl mx-auto px-5 pt-14 pb-20 grid md:grid-cols-2 gap-12 items-center relative z-10">
                  <div>
                    <div
                      className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full mb-6"
                      style={{
                        background: 'rgba(144, 243, 79, 0.12)',
                        border: '1px solid rgba(144, 243, 79, 0.3)',
                      }}
                    >
                      <span className="pulse-dot" />
                      <span
                        className="text-xs font-display tracking-wide font-semibold uppercase"
                        style={{ color: 'var(--lime)' }}
                      >
                        Live Broadcast · {listeners} Tuned In
                      </span>
                    </div>
                    <h1 className="font-display font-black text-5xl sm:text-6xl text-white leading-tight tracking-tighter">
                      SMCF <span style={{ color: 'var(--lime)' }}>Radio</span>
                    </h1>
                    <div className="mt-3 flex flex-col gap-1" style={{ color: 'var(--lime)' }}>
                      <p className="font-hi text-lg sm:text-xl font-bold tracking-wide">
                        आपकी आवाज़, आपका रेडियो
                      </p>
                      <p className="font-display text-lg sm:text-xl font-bold tracking-wide">
                        Aapki Awaaz, Aapka Radio
                      </p>
                    </div>
                    <p
                      className="mt-5 text-sm max-w-md text-white/70 leading-relaxed font-medium"
                    >
                      The official broadcasting hub of our institution — music, comedy, 
                      academic guidance, and live student talk. Curated by university students, for the campus.
                    </p>

                    <div className="mt-8 flex flex-wrap items-center gap-4">
                      <button
                        onClick={() => setPlaying((p) => !p)}
                        className="flex items-center gap-3 pl-3 pr-6 py-2.5 rounded-full font-bold text-xs uppercase tracking-wider transition-all card-hover shadow-lg cursor-pointer"
                        style={{
                          background: 'var(--lime)',
                          color: 'var(--navy-deep)',
                        }}
                      >
                        <span
                          className="w-8 h-8 rounded-full flex items-center justify-center shadow"
                          style={{ background: 'var(--navy-deep)' }}
                        >
                          {playing ? (
                            <Pause
                              className="w-3.5 h-3.5 text-lime fill-lime"
                              style={{
                                backgroundColor: '#5aff00',
                                borderColor: '#020c1c',
                                marginLeft: '2px',
                                width: '14px',
                                borderStyle: 'solid',
                                borderRadius: '0px',
                                borderWidth: '0px',
                              }}
                            />
                          ) : (
                            <Play
                              className="w-3.5 h-3.5 text-lime fill-lime"
                              style={{
                                backgroundColor: '#5aff00',
                                borderColor: '#020c1c',
                                marginLeft: '2px',
                                width: '14px',
                                borderStyle: 'solid',
                                borderRadius: '0px',
                                borderWidth: '0px',
                              }}
                            />
                          )}
                        </span>
                        {playing ? 'Pause Stream' : 'Listen Live'}
                      </button>
                      <button
                        onClick={() => setTab('portal')}
                        className="flex items-center gap-2 px-6 py-3 rounded-full font-bold text-xs uppercase tracking-wider border transition-all hover:bg-white/10"
                        style={{
                          borderColor: 'rgba(255,255,255,0.3)',
                          color: '#fff',
                        }}
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        Explore Show Vault
                      </button>
                    </div>

                    <div className="mt-8 flex items-center gap-4">
                      <div className={`eq ${playing ? '' : 'paused'}`}>
                        <span />
                        <span />
                        <span />
                        <span />
                        <span />
                      </div>
                      <p
                        className="text-xs font-medium text-white/80"
                      >
                        Currently casting:{' '}
                        <span className="font-bold text-white">
                          {nowPlaying.title}
                        </span>{' '}
                        — {nowPlaying.rj}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col items-center md:items-end gap-6">
                    <TunerStrip />
                    <div className="grid grid-cols-3 gap-3 w-full max-w-xl">
                      {[
                        { v: '12', l: 'Shows / week' },
                        { v: '3', l: 'Student RJs' },
                        { v: '5.2k+', l: 'Monthly plays' },
                      ].map((s, i) => (
                        <div
                          key={i}
                          className="rounded-2xl px-4 py-4 text-center bg-white/5 border border-white/10 backdrop-blur-sm"
                        >
                          <div
                            className="font-display font-extrabold text-2xl tracking-tight"
                            style={{ color: 'var(--lime)' }}
                          >
                            {s.v}
                          </div>
                          <div
                            className="text-[10px] uppercase font-bold tracking-wider mt-1 text-white/50"
                          >
                            {s.l}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </section>

              {/* Endless Scrolling Campus News Ticker */}
              <CampusTicker />

              {/* Live Program Daily Schedule */}
              <section className="py-14" style={{ background: 'var(--navy-deep)' }}>
                <div className="max-w-6xl mx-auto px-5">
                  <div className="mb-6">
                    <h2 className="font-display font-extrabold text-xl text-white tracking-tight">
                      Today's Live Line-Up
                    </h2>
                    <p
                      className="text-xs mt-1"
                      style={{ color: 'rgba(255,255,255,0.5)' }}
                    >
                      The current live broadcast schedule, updated by active student RJs.
                    </p>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                    {SCHEDULE.map((s, i) => {
                      const dotColors = {
                        done: 'rgba(255,255,255,0.25)',
                        live: 'var(--lime)',
                        next: 'var(--blue)',
                      };
                      return (
                        <div
                          key={i}
                          className="rounded-xl p-4 flex flex-col justify-between"
                          style={{
                            background:
                              s.status === 'live'
                                ? 'rgba(144, 243, 79, 0.1)'
                                : 'rgba(255,255,255,0.04)',
                            border:
                              s.status === 'live'
                                ? '1px solid rgba(144, 243, 79, 0.4)'
                                : '1px solid rgba(255,255,255,0.06)',
                          }}
                        >
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <span
                                className="w-2 h-2 rounded-full"
                                style={{ background: dotColors[s.status] }}
                              />
                              <span
                                className="text-[10px] font-display font-bold tracking-wider text-white/55"
                              >
                                {s.time}
                              </span>
                            </div>
                            <div className="text-xs font-bold text-white leading-snug">
                              {s.title}
                            </div>
                          </div>
                          <div className="text-[11px] mt-3 flex justify-between items-center text-white/50 font-medium">
                            <span>{s.rj}</span>
                            {s.status === 'live' && (
                              <span
                                className="text-[9px] font-display font-bold tracking-widest uppercase text-lime animate-pulse"
                              >
                                ON AIR
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </section>

              {/* Handpicked Public Features Section */}
              <section className="py-16 bg-paper">
                <div className="max-w-6xl mx-auto px-5">
                  <div className="mb-8">
                    <h2
                      className="font-display font-bold text-2xl tracking-tight"
                      style={{ color: 'var(--navy-deep)' }}
                    >
                      Top Broadcast Highlight
                    </h2>
                    <p
                      className="text-xs mt-1 text-gray-500"
                    >
                      Popular talk and music episodes trending this week. Authenticate as student to access full listings.
                    </p>
                  </div>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
                    {PROGRAMS.filter((p) => p.featured).map((p) => (
                      <ProgramCard
                        key={p.id}
                        p={p}
                        onPlay={handlePlayProgram}
                        showBookmark={false}
                      />
                    ))}
                  </div>
                </div>
              </section>

              {/* Student Broadcasters Section */}
              <section className="py-16 bg-white border-t border-gray-100">
                <div className="max-w-6xl mx-auto px-5">
                  <div className="mb-8">
                    <h2
                      className="font-display font-bold text-2xl tracking-tight"
                      style={{ color: 'var(--navy-deep)' }}
                    >
                      Meet the Campus RJs
                    </h2>
                    <p className="text-xs mt-1 text-gray-500">
                      The voices behind SMCF Radio. Find them around campus or leave them show suggestions!
                    </p>
                  </div>
                  <div className="grid sm:grid-cols-3 gap-5">
                    {RJS.map((r, i) => (
                      <div
                        key={i}
                        className="rounded-2xl p-6 card-hover flex flex-col justify-between"
                        style={{
                          background: 'var(--paper)',
                          border: '1px solid rgba(11,60,111,0.06)',
                        }}
                      >
                        <div>
                          <div
                            className="w-12 h-12 rounded-full flex items-center justify-center font-display font-bold text-white text-base mb-4 shadow-sm"
                            style={{ background: r.color }}
                          >
                            {r.initials}
                          </div>
                          <div
                            className="font-display font-bold text-base"
                            style={{ color: 'var(--navy-deep)' }}
                          >
                            {r.alias}
                          </div>
                          <div
                            className="text-[11px] font-semibold mt-0.5"
                            style={{ color: 'rgba(10,31,51,0.45)' }}
                          >
                            {r.name} · {r.dept}
                          </div>
                          <p
                            className="text-xs mt-4 leading-relaxed font-medium"
                            style={{ color: 'rgba(10,31,51,0.65)' }}
                          >
                            {r.bio}
                          </p>
                        </div>
                        <div className="mt-5 pt-3 border-t border-gray-200/60 flex items-center gap-1.5 text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                          <Award className="w-3.5 h-3.5" /> Friday Broadcaster
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* Clean Footer */}
              <footer className="pb-28 pt-14 text-white" style={{ background: 'var(--navy-deep)' }}>
                <div className="max-w-6xl mx-auto px-5 flex flex-col sm:flex-row justify-between gap-6 border-t border-white/5 pt-10">
                  <div>
                    <div className="font-display font-extrabold text-white text-base tracking-tight">
                      SMCF Radio
                    </div>
                    <div className="mt-1.5 flex flex-col gap-0.5 text-xs font-semibold" style={{ color: 'var(--lime)' }}>
                      <p className="font-hi">आपकी आवाज़, आपका रेडियो</p>
                      <p className="font-display">Aapki Awaaz, Aapka Radio</p>
                    </div>
                  </div>
                  <p
                    className="text-[10px] max-w-sm text-white/40 leading-relaxed font-medium"
                  >
                    Proof-of-concept student application. Audio stream broadcasts public ambient beats. 
                    All administrative moderation lists and bookmarked state persist within local session scope.
                  </p>
                </div>
              </footer>
            </motion.div>
          )}

          {tab === 'portal' && (
            <motion.div
              key="portal"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
            >
              <StudentPortal onPlay={handlePlayProgram} />
            </motion.div>
          )}

          {tab === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
            >
              <AdminConsole
                isLive={isLive}
                setIsLive={setIsLive}
                nowPlaying={nowPlaying}
                setNowPlaying={setNowPlaying}
                listeners={listeners}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Persistent Floating Bottom Media controller bar */}
      <NowPlayingBar
        isLive={isLive}
        nowPlaying={nowPlaying}
        playing={playing}
        setPlaying={setPlaying}
        listeners={listeners}
      />
    </div>
  );
}

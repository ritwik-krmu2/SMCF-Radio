import { useState } from 'react';
import { Radio, Check, X, Shield, Headphones, Users, Play, BarChart3, MessageSquare, Music } from 'lucide-react';
import { RJS, PROGRAMS, WEEKLY_PLAYS, CATEGORY_PLAYS, INITIAL_REQUESTS, INITIAL_COMMENTS } from '../data';
import { Program, SongRequest, Comment } from '../types';

interface AdminConsoleProps {
  isLive: boolean;
  setIsLive: (live: boolean) => void;
  nowPlaying: { title: string; rj: string };
  setNowPlaying: (np: { title: string; rj: string }) => void;
  listeners: number;
}

export function AdminConsole({
  isLive,
  setIsLive,
  nowPlaying,
  setNowPlaying,
  listeners,
}: AdminConsoleProps) {
  const [loggedIn, setLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Local state for broadcast panel inputs
  const [showTitle, setShowTitle] = useState('');
  const [rj, setRj] = useState(RJS[0].alias);
  const [justWentLive, setJustWentLive] = useState(false);

  // Lists state
  const [requests, setRequests] = useState<SongRequest[]>(INITIAL_REQUESTS);
  const [comments, setComments] = useState<Comment[]>(INITIAL_COMMENTS);

  const resolveRequest = (id: number, status: 'queued' | 'dismissed') => {
    setRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status } : r))
    );
  };

  const resolveComment = (id: number, status: 'approved' | 'removed') => {
    setComments((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status } : c))
    );
  };

  const handleGoLive = () => {
    setIsLive(true);
    setNowPlaying({
      title: showTitle.trim() || 'Live from the Studio',
      rj,
    });
    setJustWentLive(true);
    setTimeout(() => setJustWentLive(false), 3500);
  };

  if (!loggedIn) {
    return (
      <section
        className="min-h-[75vh] flex items-center justify-center px-5 py-20"
        style={{
          background: 'linear-gradient(160deg, var(--forest), var(--navy-deep))',
        }}
      >
        <div className="w-full max-w-sm rounded-2xl p-8 bg-white shadow-2xl">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center mb-6"
            style={{ background: 'var(--navy-deep)' }}
          >
            <Shield className="w-6 h-6 text-lime" />
          </div>
          <h2
            className="font-display font-bold text-2xl tracking-tight"
            style={{ color: 'var(--navy-deep)' }}
          >
            broadcaster console
          </h2>
          <p className="text-xs mt-1.5 mb-6 text-gray-500 leading-relaxed">
            Broadcaster credentials verify credentials locally for security. For
            this demonstration, any administrative logins are accepted.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (email.trim() && password.trim()) {
                setLoggedIn(true);
              }
            }}
            className="space-y-4"
          >
            <div>
              <label
                className="text-[11px] font-bold uppercase tracking-wider text-gray-700"
              >
                Admin Email ID
              </label>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@smcf.edu.in"
                className="w-full mt-1.5 px-3 py-2.5 rounded-lg border text-sm outline-none focus:ring-2 focus:ring-[#0B3C6F] transition-all"
                style={{ borderColor: 'rgba(11,60,111,0.2)' }}
              />
            </div>
            <div>
              <label
                className="text-[11px] font-bold uppercase tracking-wider text-gray-700"
              >
                Password
              </label>
              <input
                required
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full mt-1.5 px-3 py-2.5 rounded-lg border text-sm outline-none focus:ring-2 focus:ring-[#0B3C6F] transition-all"
                style={{ borderColor: 'rgba(11,60,111,0.2)' }}
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-full font-semibold mt-4 shadow-md hover:shadow-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2"
              style={{ background: 'var(--navy-deep)', color: 'var(--lime)' }}
            >
              <Play className="w-4 h-4 fill-current" />
              Enter broadcaster deck
            </button>
          </form>
        </div>
      </section>
    );
  }

  // Pure SVG vertical bar chart data calculations
  const maxWeeklyPlays = Math.max(...WEEKLY_PLAYS.map((d) => d.plays));
  const totalCategoryPlays = CATEGORY_PLAYS.reduce((sum, c) => sum + c.value, 0);

  return (
    <section className="min-h-[75vh] pb-24" style={{ background: 'var(--paper)' }}>
      <div className="max-w-6xl mx-auto px-5 pt-10">
        {/* Admin Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h2
              className="font-display font-bold text-2xl tracking-tight"
              style={{ color: 'var(--navy-deep)' }}
            >
              Broadcaster Console
            </h2>
            <p
              className="text-xs mt-1"
              style={{ color: 'rgba(10,31,51,0.55)' }}
            >
              Review active metrics, manage broadcast streams, queue songs, and moderate user interactions.
            </p>
          </div>
          <button
            onClick={() => setLoggedIn(false)}
            className="px-4 py-2 rounded-full text-xs font-semibold tracking-wide border hover:bg-gray-100 transition-all bg-white"
            style={{ borderColor: 'rgba(11,60,111,0.2)', color: 'var(--navy)' }}
          >
            Log Out Console
          </button>
        </div>

        {/* Dynamic Station Statistics Counters */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Plays', value: '5,247', icon: Play },
            { label: 'Subscribers', value: '1,382', icon: Users },
            { label: 'Active Listeners', value: String(listeners), icon: Headphones },
            { label: 'Indexed Episodes', value: String(PROGRAMS.length), icon: Radio },
          ].map((stat, idx) => {
            const IconComponent = stat.icon;
            return (
              <div
                key={idx}
                className="rounded-2xl p-5 bg-white shadow-sm flex flex-col justify-between"
                style={{ border: '1px solid rgba(11,60,111,0.08)' }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">
                    {stat.label}
                  </span>
                  <IconComponent className="w-4 h-4 text-[#246A4B]" />
                </div>
                <div
                  className="font-display font-bold text-2xl mt-4 leading-none"
                  style={{ color: 'var(--navy-deep)' }}
                >
                  {stat.value}
                </div>
              </div>
            );
          })}
        </div>

        {/* Dashboard Grid Row */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Active Broadcast Control Center */}
          <div
            className="rounded-2xl p-6 text-white flex flex-col justify-between h-full"
            style={{ background: 'var(--navy-deep)' }}
          >
            <div>
              <div className="flex items-center gap-2.5 mb-2">
                {isLive && <span className="pulse-dot"></span>}
                <h3 className="font-display font-bold text-base text-white">
                  Live Stream Switcher
                </h3>
              </div>
              <p
                className="text-xs mb-5 leading-relaxed text-gray-300"
              >
                Pushes metadata changes instantly down to the player panel.
              </p>

              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-semibold tracking-wider text-gray-300 uppercase">
                    Broadcast Show Title
                  </label>
                  <input
                    value={showTitle}
                    onChange={(e) => setShowTitle(e.target.value)}
                    placeholder="e.g. Beats of the West"
                    className="w-full mt-1.5 px-3 py-2 rounded-lg text-xs outline-none border focus:ring-1 focus:ring-lime"
                    style={{
                      background: 'rgba(255,255,255,0.08)',
                      color: '#fff',
                      borderColor: 'rgba(255,255,255,0.15)',
                    }}
                  />
                </div>

                <div>
                  <label className="text-[10px] font-semibold tracking-wider text-gray-300 uppercase">
                    Active Broadcaster RJ
                  </label>
                  <select
                    value={rj}
                    onChange={(e) => setRj(e.target.value)}
                    className="w-full mt-1.5 px-3 py-2 rounded-lg text-xs outline-none border focus:ring-1 focus:ring-lime"
                    style={{
                      background: 'rgba(255,255,255,0.08)',
                      color: '#fff',
                      borderColor: 'rgba(255,255,255,0.15)',
                    }}
                  >
                    {RJS.map((r) => (
                      <option
                        key={r.alias}
                        value={r.alias}
                        style={{ color: '#000' }}
                      >
                        {r.alias}
                      </option>
                    ))}
                    <option value="Auto DJ" style={{ color: '#000' }}>
                      Auto DJ (Automated Playlist)
                    </option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-5 border-t border-white/10">
              {!isLive ? (
                <button
                  onClick={handleGoLive}
                  className="w-full py-2.5 rounded-full font-semibold text-xs tracking-wide flex items-center justify-center gap-2 shadow hover:bg-opacity-90 active:scale-[0.98] transition-all"
                  style={{ background: 'var(--lime)', color: 'var(--navy-deep)' }}
                >
                  <Play className="w-3.5 h-3.5 fill-current" /> Launch On Air Broadcaster
                </button>
              ) : (
                <button
                  onClick={() => setIsLive(false)}
                  className="w-full py-2.5 rounded-full font-semibold text-xs tracking-wide border hover:bg-white/10 active:scale-[0.98] transition-all"
                  style={{ borderColor: 'rgba(255,255,255,0.3)', color: '#fff' }}
                >
                  Terminate Active Broadcast
                </button>
              )}

              {justWentLive && (
                <p
                  className="text-[10px] mt-3 flex items-center gap-1.5 font-medium"
                  style={{ color: 'var(--lime)' }}
                >
                  <Check className="w-3.5 h-3.5" /> Stream configured. Active metadata dispatched successfully.
                </p>
              )}
            </div>
          </div>

          {/* Weekly Plays Bar Chart */}
          <div
            className="rounded-2xl p-6 bg-white"
            style={{ border: '1px solid rgba(11,60,111,0.08)' }}
          >
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 className="w-4 h-4 text-[#246A4B]" />
              <h3 className="font-display font-bold text-base" style={{ color: 'var(--navy-deep)' }}>
                Weekly Plays
              </h3>
            </div>
            <p className="text-[11px] text-gray-400 mb-6">
              Hourly aggregate of listeners parsed weekly.
            </p>

            <div className="flex items-end gap-3 h-40">
              {WEEKLY_PLAYS.map((dayData, idx) => {
                const heightPercent = maxWeeklyPlays > 0 ? (dayData.plays / maxWeeklyPlays) * 100 : 0;
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                    <div className="w-full relative group">
                      {/* Tooltip */}
                      <span className="absolute -top-7 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[9px] px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-10">
                        {dayData.plays} plays
                      </span>
                      <div
                        className="w-full rounded-t-md hover:opacity-90 transition-all cursor-pointer"
                        style={{
                          height: `${Math.max(6, heightPercent)}%`,
                          background: 'linear-gradient(180deg, var(--lime), var(--leaf))',
                        }}
                      />
                    </div>
                    <span
                      className="text-[10px] font-display font-bold text-gray-400"
                    >
                      {dayData.day}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Horizontal Category Distribution */}
          <div
            className="rounded-2xl p-6 bg-white"
            style={{ border: '1px solid rgba(11,60,111,0.08)' }}
          >
            <h3
              className="font-display font-bold text-base mb-1"
              style={{ color: 'var(--navy-deep)' }}
            >
              Category Metrics
            </h3>
            <p className="text-[11px] text-gray-400 mb-5">
              {totalCategoryPlays.toLocaleString()} total plays indexed this month
            </p>

            <div className="space-y-3.5">
              {CATEGORY_PLAYS.map((item, idx) => {
                const percentage = totalCategoryPlays > 0 ? (item.value / totalCategoryPlays) * 100 : 0;
                return (
                  <div key={idx} className="text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-semibold text-gray-700">{item.label}</span>
                      <span className="text-[10px] font-bold text-gray-400">
                        {item.value} plays ({Math.round(percentage)}%)
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-gray-100 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${percentage}%`,
                          background: item.color,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Moderation Row */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Song Request moderation queue */}
          <div
            className="rounded-2xl p-6 bg-white"
            style={{ border: '1px solid rgba(11,60,111,0.08)' }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Music className="w-4 h-4 text-[#246A4B]" />
              <h3
                className="font-display font-bold text-base"
                style={{ color: 'var(--navy-deep)' }}
              >
                Inbound Song Requests
              </h3>
            </div>
            <div className="space-y-3 max-h-72 overflow-y-auto scrollbar-slim pr-1">
              {requests.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between gap-3 text-xs p-3 rounded-xl bg-gray-50 border border-gray-100 transition-all"
                >
                  <div className="min-w-0 flex-1">
                    <div className="font-bold truncate text-gray-800">
                      {r.song}{' '}
                      <span className="font-normal text-gray-500">— {r.by}</span>
                    </div>
                    <div className="text-[10px] text-gray-400 mt-0.5">
                      Requested by: {r.from}
                    </div>
                  </div>

                  <div className="shrink-0">
                    {r.status === 'pending' ? (
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => resolveRequest(r.id, 'queued')}
                          title="Approve to playlist"
                          className="w-7 h-7 rounded-full flex items-center justify-center bg-emerald-100 text-emerald-800 hover:scale-105 active:scale-95 transition-all"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => resolveRequest(r.id, 'dismissed')}
                          title="Reject request"
                          className="w-7 h-7 rounded-full flex items-center justify-center bg-red-100 text-red-800 hover:scale-105 active:scale-95 transition-all"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <span
                        className="text-[9px] font-display font-bold px-2 py-0.5 rounded tracking-wide uppercase"
                        style={{
                          background: r.status === 'queued' ? '#E6F4EA' : '#FCE8E6',
                          color: r.status === 'queued' ? '#137333' : '#C5221F',
                        }}
                      >
                        {r.status}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Comments moderation board */}
          <div
            className="rounded-2xl p-6 bg-white"
            style={{ border: '1px solid rgba(11,60,111,0.08)' }}
          >
            <div className="flex items-center gap-2 mb-4">
              <MessageSquare className="w-4 h-4 text-[#246A4B]" />
              <h3
                className="font-display font-bold text-base"
                style={{ color: 'var(--navy-deep)' }}
              >
                Comment Moderation Queue
              </h3>
            </div>
            <div className="space-y-3 max-h-72 overflow-y-auto scrollbar-slim pr-1">
              {comments.map((c) => (
                <div
                  key={c.id}
                  className="flex items-center justify-between gap-3 text-xs p-3 rounded-xl bg-gray-50 border border-gray-100 transition-all"
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-gray-800 leading-relaxed">
                      <span className="font-bold text-emerald-800">
                        {c.author}:
                      </span>{' '}
                      {c.text}
                    </div>
                    <div className="text-[10px] text-gray-400 mt-1 truncate">
                      on: {c.program}
                    </div>
                  </div>

                  <div className="shrink-0">
                    {c.status === 'pending' ? (
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => resolveComment(c.id, 'approved')}
                          title="Approve post"
                          className="w-7 h-7 rounded-full flex items-center justify-center bg-emerald-100 text-emerald-800 hover:scale-105 active:scale-95 transition-all"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => resolveComment(c.id, 'removed')}
                          title="Delete comment"
                          className="w-7 h-7 rounded-full flex items-center justify-center bg-red-100 text-red-800 hover:scale-105 active:scale-95 transition-all"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <span
                        className="text-[9px] font-display font-bold px-2 py-0.5 rounded tracking-wide uppercase"
                        style={{
                          background: c.status === 'approved' ? '#E6F4EA' : '#FCE8E6',
                          color: c.status === 'approved' ? '#137333' : '#C5221F',
                        }}
                      >
                        {c.status}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

import { ANNOUNCEMENTS } from '../data';

export function CampusTicker() {
  const loop = [...ANNOUNCEMENTS, ...ANNOUNCEMENTS, ...ANNOUNCEMENTS];

  return (
    <div className="overflow-hidden py-2" style={{ background: 'var(--lime)' }}>
      <div className="ticker-track">
        {loop.map((a, i) => (
          <span
            key={i}
            className="whitespace-nowrap px-8 text-xs font-semibold uppercase tracking-wider font-display flex items-center gap-2"
            style={{ color: 'var(--navy-deep)' }}
          >
            <span>{a.en}</span>
            <span className="font-hi font-normal opacity-70">
              · {a.hi}
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}

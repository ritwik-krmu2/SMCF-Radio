import { Play, Pause, Headphones } from 'lucide-react';

interface NowPlayingBarProps {
  isLive: boolean;
  nowPlaying: { title: string; rj: string };
  playing: boolean;
  setPlaying: (playing: boolean | ((p: boolean) => boolean)) => void;
  listeners: number;
}

export function NowPlayingBar({
  isLive,
  nowPlaying,
  playing,
  setPlaying,
  listeners,
}: NowPlayingBarProps) {
  return (
    <div
      className="fixed bottom-0 inset-x-0 z-40 transition-transform duration-300 shadow-2xl"
      style={{
        background: 'var(--navy-deep)',
        borderTop: '1px solid rgba(144, 243, 79, 0.25)',
      }}
    >
      <div className="max-w-6xl mx-auto px-5 py-3 flex items-center gap-4">
        {/* Playback Control Trigger */}
        <button
          onClick={() => setPlaying((p) => !p)}
          className="w-11 h-11 shrink-0 rounded-full flex items-center justify-center transition-all hover:scale-105 active:scale-95 shadow-md"
          style={{ background: 'var(--lime)' }}
          aria-label={playing ? 'Pause live stream' : 'Play live stream'}
        >
          {playing ? (
            <Pause className="w-5 h-5 text-navy-deep fill-navy-deep" />
          ) : (
            <Play className="w-5 h-5 text-navy-deep fill-navy-deep ml-0.5" />
          )}
        </button>

        {/* Dynamic Graphic Equalizer */}
        <div className={`eq shrink-0 ${playing ? '' : 'paused'}`}>
          <span />
          <span />
          <span />
          <span />
          <span />
        </div>

        {/* Live Station Metadata Output */}
        <div className="min-w-0 flex-1 pl-1">
          <div className="flex items-center gap-2">
            {isLive && <span className="pulse-dot shrink-0" />}
            <span
              className="text-[10px] font-display font-bold tracking-wider uppercase"
              style={{ color: isLive ? 'var(--lime)' : 'rgba(255,255,255,0.5)' }}
            >
              {isLive ? 'On Air' : 'Off Air · Recording Playback'}
            </span>
          </div>
          <div className="text-sm font-semibold text-white truncate leading-snug">
            {nowPlaying.title}{' '}
            <span className="opacity-60 font-normal text-xs">— {nowPlaying.rj}</span>
          </div>
        </div>

        {/* Real-time active listener indicator */}
        <div
          className="hidden sm:flex items-center gap-2 text-xs font-display font-medium px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10"
          style={{ color: 'rgba(255,255,255,0.65)' }}
        >
          <Headphones className="w-3.5 h-3.5 text-lime" />
          <span>{listeners} listening</span>
        </div>
      </div>
    </div>
  );
}

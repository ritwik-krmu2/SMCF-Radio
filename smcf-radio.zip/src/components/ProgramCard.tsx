import React from 'react';
import { Music, Megaphone, Brain, Mic, PartyPopper, Briefcase, Bookmark, Play } from 'lucide-react';
import { Program } from '../types';
import { catBySlug } from '../data';

interface ProgramCardProps {
  key?: React.Key;
  p: Program;
  onPlay: (p: Program) => void;
  bookmarked?: boolean;
  onBookmark?: (id: number) => void;
  showBookmark?: boolean;
}

// Map slug to Lucide Icon
const ICON_MAP: Record<string, React.ComponentType<any>> = {
  'music-2': Music,
  'megaphone': Megaphone,
  'brain': Brain,
  'mic-2': Mic,
  'party-popper': PartyPopper,
  'briefcase': Briefcase,
};

export function ProgramCard({
  p,
  onPlay,
  bookmarked = false,
  onBookmark,
  showBookmark = false,
}: ProgramCardProps) {
  const cat = catBySlug[p.cat];
  const CategoryIcon = ICON_MAP[cat.icon] || Music;

  return (
    <div
      className="rounded-2xl overflow-hidden card-hover flex flex-col justify-between h-full"
      style={{
        background: '#fff',
        border: '1px solid rgba(11, 60, 111, 0.1)',
      }}
    >
      <div>
        <div
          className="h-28 flex items-center justify-between px-5 transition-all"
          style={{ background: cat.color }}
        >
          <div>
            <div className="text-white/90 text-[10px] font-display font-bold uppercase tracking-widest">
              {cat.en}
            </div>
            <div className="text-white/70 text-[11px] font-hi mt-0.5">
              {cat.hi}
            </div>
          </div>
          <CategoryIcon className="w-6 h-6 text-white/80" />
        </div>
        <div className="p-5 pb-2">
          <div className="flex items-center gap-2 mb-1.5">
            <span
              className="text-[9px] font-display font-bold px-1.5 py-0.5 rounded tracking-wide uppercase"
              style={{ background: 'var(--paper)', color: 'var(--navy)' }}
            >
              {p.lang}
            </span>
            <span
              className="text-[11px] font-medium"
              style={{ color: 'rgba(10,31,51,0.5)' }}
            >
              {p.duration}
            </span>
          </div>
          <h3
            className="font-display font-bold text-sm leading-snug tracking-tight"
            style={{ color: 'var(--navy-deep)' }}
          >
            {p.title}
          </h3>
          <p
            className="text-xs mt-0.5 font-hi font-medium"
            style={{ color: 'rgba(10,31,51,0.5)' }}
          >
            {p.titleHi}
          </p>
          <p
            className="text-xs mt-2 leading-relaxed"
            style={{ color: 'rgba(10,31,51,0.65)' }}
          >
            {p.desc}
          </p>
        </div>
      </div>
      <div className="p-5 pt-2">
        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div className="min-w-0">
            <div
              className="text-xs font-semibold truncate"
              style={{ color: 'var(--navy-deep)' }}
            >
              {p.rj}
            </div>
            <div
              className="text-[10px]"
              style={{ color: 'rgba(10,31,51,0.5)' }}
            >
              {p.plays.toLocaleString()} plays
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {showBookmark && onBookmark && (
              <button
                onClick={() => onBookmark(p.id)}
                aria-label="Bookmark episode"
                className="w-8 h-8 rounded-full flex items-center justify-center transition hover:scale-105 active:scale-95"
                style={{
                  background: bookmarked ? 'var(--lime)' : 'var(--paper)',
                }}
              >
                <Bookmark
                  className="w-3.5 h-3.5"
                  style={{
                    color: bookmarked ? 'var(--navy-deep)' : 'var(--navy)',
                    fill: bookmarked ? 'var(--navy-deep)' : 'none',
                  }}
                />
              </button>
            )}
            <button
              onClick={() => onPlay(p)}
              aria-label={`Play ${p.title}`}
              className="w-9 h-9 rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-md cursor-pointer"
              style={{ background: 'var(--lime)', color: 'var(--navy-deep)' }}
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { LogOut, Bookmark, Play, X, Check, MessageSquare, Search, Award } from 'lucide-react';
import { Program } from '../types';
import { PROGRAMS, CATEGORIES } from '../data';
import { ProgramCard } from './ProgramCard';

interface StudentPortalProps {
  onPlay: (p: Program) => void;
}

export function StudentPortal({ onPlay }: StudentPortalProps) {
  const [loggedIn, setLoggedIn] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [view, setView] = useState<'home' | 'archive'>('home');
  const [filter, setFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarks, setBookmarks] = useState<Set<number>>(new Set());
  const [activeEpisode, setActiveEpisode] = useState<Program | null>(null);

  // Simulated comments mapped by Program ID
  const [commentsByProgram, setCommentsByProgram] = useState<Record<number, Array<{ author: string; text: string }>>>({
    1: [
      { author: 'Vikram, CS', text: 'Amazing interview! Loved the section on campus labs.' },
      { author: 'Meera, Arts', text: 'So proud of our student council!' },
    ],
    2: [
      { author: 'Rohan, Mech', text: 'The active recall method mentioned here is a lifesaver.' },
    ],
    3: [
      { author: 'Anjali, Comm', text: 'Haha RJ Ananya is a comedic genius. Best podcast on campus!' },
    ],
  });

  const [draft, setDraft] = useState('');

  const toggleBookmark = (id: number) => {
    setBookmarks((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handlePostComment = () => {
    if (!draft.trim() || !activeEpisode) return;
    setCommentsByProgram((prev) => {
      const currentList = prev[activeEpisode.id] || [];
      return {
        ...prev,
        [activeEpisode.id]: [
          ...currentList,
          { author: name || 'Student', text: draft.trim() },
        ],
      };
    });
    setDraft('');
  };

  // Filter & Search Logic
  const filteredPrograms = PROGRAMS.filter((p) => {
    const matchesCat = filter === 'all' || p.cat === filter;
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.desc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.rj.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handlePlayAndSelect = (p: Program) => {
    onPlay(p);
    setActiveEpisode(p);
  };

  if (!loggedIn) {
    return (
      <section
        className="min-h-[75vh] flex items-center justify-center px-5 py-20"
        style={{
          background: 'linear-gradient(160deg, var(--navy-deep), var(--forest))',
        }}
      >
        <div className="w-full max-w-sm rounded-2xl p-8 bg-white shadow-2xl">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center font-display font-bold mb-6 text-xl"
            style={{ background: 'var(--lime)', color: 'var(--navy-deep)' }}
          >
            S
          </div>
          <h2
            className="font-display font-bold text-2xl tracking-tight"
            style={{ color: 'var(--navy-deep)' }}
          >
            Student Sign-In
          </h2>
          <p className="text-xs mt-1.5 mb-6 text-gray-500 leading-relaxed">
            Access the full broadcast archive, curate playlists, bookmark
            episodes, and join the live comment board.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (name.trim() && email.trim()) {
                setLoggedIn(true);
              }
            }}
            className="space-y-4"
          >
            <div>
              <label
                className="text-[11px] font-bold uppercase tracking-wider"
                style={{ color: 'var(--navy)' }}
              >
                Your Name
              </label>
              <input
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Ananya Roy"
                className="w-full mt-1.5 px-3 py-2.5 rounded-lg border text-sm outline-none focus:ring-2 focus:ring-[#72B34B] transition-all"
                style={{ borderColor: 'rgba(11,60,111,0.2)' }}
              />
            </div>
            <div>
              <label
                className="text-[11px] font-bold uppercase tracking-wider"
                style={{ color: 'var(--navy)' }}
              >
                University Email ID
              </label>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@university.edu.in"
                className="w-full mt-1.5 px-3 py-2.5 rounded-lg border text-sm outline-none focus:ring-2 focus:ring-[#72B34B] transition-all"
                style={{ borderColor: 'rgba(11,60,111,0.2)' }}
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-full font-semibold mt-4 shadow-md hover:shadow-lg transition-all active:scale-[0.98] flex items-center justify-center gap-2"
              style={{ background: 'var(--lime)', color: 'var(--navy-deep)' }}
            >
              <Play className="w-4 h-4 fill-current" />
              Enter Student Portal
            </button>
          </form>
        </div>
      </section>
    );
  }

  return (
    <section className="min-h-[75vh] pb-24" style={{ background: 'var(--paper)' }}>
      <div className="max-w-6xl mx-auto px-5 pt-10">
        {/* Portal Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h2
              className="font-display font-bold text-2xl tracking-tight"
              style={{ color: 'var(--navy-deep)' }}
            >
              Good to see you, {name || 'Student'} 👋
            </h2>
            <p
              className="text-xs mt-1"
              style={{ color: 'rgba(10,31,51,0.55)' }}
            >
              Pick up where you left off, bookmark favorite segments, or check the campus archive.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setView('home')}
              className="px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all"
              style={{
                background: view === 'home' ? 'var(--navy-deep)' : '#fff',
                color: view === 'home' ? '#fff' : 'var(--navy)',
                boxShadow: '0 2px 4px rgba(0,0,0,0.03)',
              }}
            >
              My Dashboard
            </button>
            <button
              onClick={() => setView('archive')}
              className="px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all flex items-center gap-1.5"
              style={{
                background: view === 'archive' ? 'var(--navy-deep)' : '#fff',
                color: view === 'archive' ? '#fff' : 'var(--navy)',
                boxShadow: '0 2px 4px rgba(0,0,0,0.03)',
              }}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              Audio Archive
            </button>
            <button
              onClick={() => setLoggedIn(false)}
              className="px-4 py-2 rounded-full text-xs font-semibold tracking-wide border hover:bg-gray-100 transition-all flex items-center gap-1.5"
              style={{
                borderColor: 'rgba(11,60,111,0.2)',
                color: 'var(--navy)',
                background: '#fff',
              }}
            >
              <LogOut className="w-3 h-3" /> Log Out
            </button>
          </div>
        </div>

        {/* Dashboard View */}
        {view === 'home' && (
          <div className="grid md:grid-cols-3 gap-6">
            <div
              className="md:col-span-2 rounded-2xl p-6 bg-white"
              style={{ border: '1px solid rgba(11,60,111,0.08)' }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3
                  className="font-display font-bold text-base"
                  style={{ color: 'var(--navy-deep)' }}
                >
                  Featured Student Highlights
                </h3>
                <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                  Weekly Hot
                </span>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {PROGRAMS.slice(0, 4).map((p) => (
                  <ProgramCard
                    key={p.id}
                    p={p}
                    onPlay={handlePlayAndSelect}
                    bookmarked={bookmarks.has(p.id)}
                    onBookmark={toggleBookmark}
                    showBookmark={true}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-6">
              {/* Bookmarks Section */}
              <div
                className="rounded-2xl p-6 bg-white"
                style={{ border: '1px solid rgba(11,60,111,0.08)' }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <Bookmark className="w-4 h-4 text-emerald-600" />
                  <h3
                    className="font-display font-bold text-base"
                    style={{ color: 'var(--navy-deep)' }}
                  >
                    Your Bookmarks
                  </h3>
                </div>
                {bookmarks.size === 0 ? (
                  <p
                    className="text-xs leading-relaxed"
                    style={{ color: 'rgba(10,31,51,0.5)' }}
                  >
                    No saved episodes yet. Tap the bookmark icon on any card in the Archive tab to compile your quick-listening list.
                  </p>
                ) : (
                  <div className="space-y-3 max-h-56 overflow-y-auto scrollbar-slim pr-1">
                    {PROGRAMS.filter((p) => bookmarks.has(p.id)).map((p) => (
                      <div
                        key={p.id}
                        className="flex items-center justify-between text-xs p-2 rounded bg-gray-50 border border-gray-100 hover:bg-gray-100 transition-all"
                      >
                        <span
                          className="font-medium truncate pr-2"
                          style={{ color: 'var(--navy-deep)' }}
                        >
                          {p.title}
                        </span>
                        <button
                          onClick={() => handlePlayAndSelect(p)}
                          className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 hover:scale-110 active:scale-95 transition-all shadow-sm cursor-pointer"
                          style={{ background: 'var(--lime)', color: 'var(--navy-deep)' }}
                          title="Play episode"
                        >
                          <Play className="w-3 h-3 fill-current ml-0.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Station Info banner */}
              <div
                className="rounded-2xl p-5 text-white"
                style={{
                  background: 'linear-gradient(135deg, var(--navy), var(--forest))',
                }}
              >
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-lime" />
                  <div className="font-display font-bold text-sm">Broadcaster Tip</div>
                </div>
                <p className="text-[11px] mt-2 text-white/80 leading-relaxed">
                  Join our open mic recording session every Tuesday at the mass media studios. Talk to any active student RJ to register!
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Archive View */}
        {view === 'archive' && (
          <div>
            {/* Search and Category Filters */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              {/* Search input */}
              <div className="relative w-full md:max-w-xs">
                <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search episodes, hosts, topics..."
                  className="w-full pl-9 pr-4 py-2 rounded-full text-xs border border-gray-200 bg-white shadow-sm outline-none focus:ring-2 focus:ring-[#72B34B] transition-all"
                />
              </div>

              {/* Category selector chips */}
              <div className="flex gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-slim">
                <button
                  onClick={() => setFilter('all')}
                  className="px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0 transition-all"
                  style={{
                    background: filter === 'all' ? 'var(--navy-deep)' : '#fff',
                    color: filter === 'all' ? '#fff' : 'var(--navy)',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.03)',
                  }}
                >
                  All Categories
                </button>
                {CATEGORIES.map((c) => (
                  <button
                    key={c.slug}
                    onClick={() => setFilter(c.slug)}
                    className="px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0 transition-all"
                    style={{
                      background: filter === c.slug ? c.color : '#fff',
                      color: filter === c.slug ? '#fff' : 'var(--navy)',
                      boxShadow: '0 1px 3px rgba(0,0,0,0.03)',
                    }}
                  >
                    {c.en}
                  </button>
                ))}
              </div>
            </div>

            {filteredPrograms.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-gray-200">
                <p className="text-sm font-semibold text-gray-500">
                  No shows found matching "{searchQuery}" under this category.
                </p>
                <button
                  onClick={() => {
                    setFilter('all');
                    setSearchQuery('');
                  }}
                  className="mt-4 px-4 py-2 rounded-full text-xs font-semibold text-white bg-navy-deep hover:bg-opacity-90"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredPrograms.map((p) => (
                  <ProgramCard
                    key={p.id}
                    p={p}
                    onPlay={handlePlayAndSelect}
                    bookmarked={bookmarks.has(p.id)}
                    onBookmark={toggleBookmark}
                    showBookmark={true}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Live Discussion Thread Panel */}
        {activeEpisode && (
          <div
            className="mt-10 rounded-2xl p-6 bg-white shadow-md"
            style={{ border: '1px solid rgba(11, 60, 111, 0.08)' }}
          >
            <div className="flex items-center justify-between border-b pb-4 mb-4">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-[#246A4B]" />
                <div>
                  <div className="text-[10px] uppercase tracking-wider font-bold text-emerald-600">
                    Live Chat Board
                  </div>
                  <h3
                    className="font-display font-bold text-sm tracking-tight"
                    style={{ color: 'var(--navy-deep)' }}
                  >
                    {activeEpisode.title}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setActiveEpisode(null)}
                aria-label="Close comment board"
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
              >
                <X className="w-4 h-4 text-gray-500" />
              </button>
            </div>

            {/* Comment scrolling area */}
            <div className="space-y-3 mb-4 max-h-48 overflow-y-auto scrollbar-slim pr-1">
              {(commentsByProgram[activeEpisode.id] || []).length === 0 ? (
                <p
                  className="text-xs italic text-gray-400 py-3"
                >
                  No comments yet on this show. Be the first to spark the student discussion!
                </p>
              ) : (
                (commentsByProgram[activeEpisode.id] || []).map((c, i) => (
                  <div
                    key={i}
                    className="text-xs px-3.5 py-2.5 rounded-lg bg-gray-50 border border-gray-100 flex flex-col gap-0.5"
                  >
                    <span
                      className="font-bold text-emerald-800"
                    >
                      {c.author}
                    </span>
                    <span className="text-gray-700 leading-relaxed font-medium">
                      {c.text}
                    </span>
                  </div>
                ))
              )}
            </div>

            {/* Typing input bar */}
            <div className="flex gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Post your reaction, question, or music request..."
                className="flex-1 px-4 py-2 rounded-lg border text-xs outline-none focus:ring-2 focus:ring-[#72B34B] transition-all bg-gray-50"
                style={{ borderColor: 'rgba(11,60,111,0.2)' }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handlePostComment();
                }}
              />
              <button
                onClick={handlePostComment}
                className="px-5 py-2 rounded-lg text-xs font-semibold tracking-wide transition-all shadow-sm active:scale-[0.97]"
                style={{ background: 'var(--lime)', color: 'var(--navy-deep)' }}
              >
                Post
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

import { motion } from 'motion/react';

interface TunerStripProps {
  compact?: boolean;
}

export function TunerStrip({ compact }: TunerStripProps) {
  const marks = [88, 92, 96, 100, 104, 108];

  return (
    <div className={`w-full ${compact ? 'max-w-md' : 'max-w-xl'}`}>
      <div
        className="relative rounded-2xl px-5 py-4"
        style={{
          background: 'linear-gradient(135deg, var(--navy-deep), var(--navy))',
          border: '1px solid rgba(144, 243, 79, 0.25)',
        }}
      >
        <div className="flex items-center justify-between mb-2">
          <span
            className="text-[10px] tracking-[0.25em] uppercase font-display"
            style={{ color: 'rgba(255,255,255,0.55)' }}
          >
            FM Tuner
          </span>
          <span
            className="text-[10px] tracking-[0.25em] uppercase font-display"
            style={{ color: 'rgba(255,255,255,0.55)' }}
          >
            Campus Frequency
          </span>
        </div>
        <div
          className="relative h-14 rounded-lg overflow-hidden"
          style={{ background: 'rgba(0,0,0,0.25)' }}
        >
          <div className="absolute inset-0 flex items-end justify-between px-3 pb-2">
            {Array.from({ length: 29 }).map((_, i) => (
              <div
                key={i}
                style={{
                  width: 1,
                  height: i % 4 === 0 ? 16 : 8,
                  background:
                    i % 4 === 0
                      ? 'rgba(255,255,255,0.55)'
                      : 'rgba(255,255,255,0.22)',
                }}
              />
            ))}
          </div>
          <div className="absolute inset-x-3 bottom-1 flex justify-between">
            {marks.map((m) => (
              <span
                key={m}
                className="text-[9px] font-display font-medium"
                style={{ color: 'rgba(255,255,255,0.45)' }}
              >
                {m}
              </span>
            ))}
          </div>
          {/* SMCF Marker Dot */}
          <div className="absolute" style={{ left: '34%', top: 6 }}>
            <motion.div
              className="w-2.5 h-2.5 rounded-full"
              style={{
                background: 'var(--lime)',
                boxShadow: '0 0 10px var(--lime)',
              }}
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            />
          </div>
          {/* Sweeping Needles */}
          <motion.div
            className="absolute top-0 bottom-0"
            style={{
              left: '34%',
              width: 2,
              background: 'var(--lime)',
              boxShadow: '0 0 8px var(--lime)',
            }}
            animate={{
              x: [0, 4, -4, 0],
            }}
            transition={{
              repeat: Infinity,
              duration: 8,
              ease: 'easeInOut',
            }}
          />
        </div>
        <div className="mt-2.5 flex items-baseline gap-2">
          <span
            className="font-display font-bold text-2xl tracking-tight"
            style={{ color: 'var(--lime)' }}
          >
            94.3
          </span>
          <span
            className="text-xs font-display tracking-wide font-medium"
            style={{ color: 'rgba(255,255,255,0.65)' }}
          >
            SMCF FM · Student Frequency
          </span>
        </div>
      </div>
    </div>
  );
}

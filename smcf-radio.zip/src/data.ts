import { Category, RJ, Program, ScheduleItem, Announcement, WeeklyPlay, CategoryPlay, SongRequest, Comment } from './types';

export const COLORS = {
  navy: '#0B3C6F',
  blue: '#062CE2',
  forest: '#246A4B',
  leaf: '#72B34B',
  lime: '#90F34F'
};

export const STREAM_URL = 'https://ice6.somafm.com/groovesalad-128-mp3';

export const CATEGORIES: Category[] = [
  { slug: 'music', en: 'Music & Beats', hi: 'संगीत', icon: 'music-2', color: COLORS.leaf },
  { slug: 'campus-buzz', en: 'Campus Buzz', hi: 'कैंपस बज़', icon: 'megaphone', color: COLORS.blue },
  { slug: 'gyaan-time', en: 'Gyaan Time', hi: 'ज्ञान टाइम', icon: 'brain', color: COLORS.forest },
  { slug: 'talkback', en: 'Talkback', hi: 'टॉकबैक', icon: 'mic-2', color: COLORS.navy },
  { slug: 'masti-time', en: 'Masti Time', hi: 'मस्ती टाइम', icon: 'party-popper', color: COLORS.blue },
  { slug: 'career', en: 'Career Connect', hi: 'करियर कनेक्ट', icon: 'briefcase', color: COLORS.forest },
];

export const catBySlug = Object.fromEntries(CATEGORIES.map(c => [c.slug, c]));

export const RJS: RJ[] = [
  { name: 'Priya Sharma', alias: 'RJ Priya', dept: 'Computer Science', bio: 'Music lover, 3rd year CSE. Curates every Friday playlist.', color: COLORS.leaf, initials: 'PS' },
  { name: 'Rahul Mehta', alias: 'RJ Rahul', dept: 'Humanities', bio: 'Philosophy student. Deep talks, no small talk.', color: COLORS.blue, initials: 'RM' },
  { name: 'Ananya Roy', alias: 'RJ Ananya', dept: 'Mass Comm', bio: 'Comedy and chaos. Hosts Masti Time on Thursdays.', color: COLORS.forest, initials: 'AR' },
];

export const PROGRAMS: Program[] = [
  { id: 1, title: 'Aaj Ke Mehmaan — A Meet & Greet', titleHi: 'आज के मेहमान', desc: 'Students, faculty and visiting speakers sit down for an easy, unscripted chat.', cat: 'talkback', lang: 'HI', rj: 'RJ Priya', plays: 1247, duration: '45 min', featured: true },
  { id: 2, title: 'Exam Tips with Toppers', titleHi: 'टॉपर्स के साथ', desc: 'Final-year students share the study strategies that actually worked.', cat: 'gyaan-time', lang: 'EN', rj: 'RJ Rahul', plays: 843, duration: '38 min', featured: true },
  { id: 3, title: 'Campus Masti Episode 12', titleHi: 'कैंपस मस्ती', desc: 'Weekly comedy, memes, and campus gossip you didn’t know you needed.', cat: 'masti-time', lang: 'HI', rj: 'RJ Ananya', plays: 2103, duration: '41 min', featured: true },
  { id: 4, title: 'Placement Season Special', titleHi: 'प्लेसमेंट स्पेशल', desc: 'How to crack your first interview, straight from recruiters.', cat: 'career', lang: 'EN', rj: 'RJ Rahul', plays: 987, duration: '50 min', featured: true },
  { id: 5, title: 'Morning Motivation', titleHi: 'सुबह की प्रेरणा', desc: 'Start the day right with five minutes of positive energy.', cat: 'talkback', lang: 'EN', rj: 'RJ Rahul', plays: 654, duration: '12 min', featured: false },
  { id: 6, title: 'Campus Buzz — Weekly Roundup', titleHi: 'वीकली राउंडअप', desc: 'This week at university: news, events, deadlines.', cat: 'campus-buzz', lang: 'EN', rj: 'RJ Priya', plays: 432, duration: '20 min', featured: false },
  { id: 7, title: 'Indie India — Hidden Gems', titleHi: 'इंडी इंडिया', desc: 'Underrated Indian indie artists worth your playlist space.', cat: 'music', lang: 'EN', rj: 'RJ Priya', plays: 789, duration: '33 min', featured: false },
  { id: 8, title: 'Tech Talk — AI & Future', titleHi: 'टेक टॉक', desc: 'AI, startups and innovation, explained for students.', cat: 'talkback', lang: 'EN', rj: 'RJ Rahul', plays: 561, duration: '29 min', featured: false },
];

export const SCHEDULE: ScheduleItem[] = [
  { time: '8:00 AM', title: 'Morning Motivation', rj: 'RJ Rahul', status: 'done' },
  { time: '12:00 PM', title: 'Aaj Ke Mehmaan', rj: 'RJ Priya', status: 'live' },
  { time: '2:30 PM', title: 'Campus Buzz — Evening Edition', rj: 'RJ Priya', status: 'next' },
  { time: '4:00 PM', title: 'Masti Time', rj: 'RJ Ananya', status: 'next' },
  { time: '5:30 PM', title: 'Night Owl Lo-Fi', rj: 'Auto DJ', status: 'next' },
];

export const ANNOUNCEMENTS: Announcement[] = [
  { en: '📚 End-semester exams begin Monday — best of luck from Team SMCF Radio!', hi: 'सोमवार से परीक्षाएं — शुभकामनाएं!' },
  { en: '🎉 Techfest 2026 registrations are OPEN — register now!', hi: 'टेकफेस्ट 2026 रजिस्ट्रेशन खुली है!' },
  { en: '🎧 Send us your song requests — link in the student portal.', hi: 'अपने पसंदीदा गाने भेजें — स्टूडेंट पोर्टल में!' },
];

export const WEEKLY_PLAYS: WeeklyPlay[] = [
  { day: 'Mon', plays: 420 },
  { day: 'Tue', plays: 512 },
  { day: 'Wed', plays: 388 },
  { day: 'Thu', plays: 640 },
  { day: 'Fri', plays: 905 },
  { day: 'Sat', plays: 1180 },
  { day: 'Sun', plays: 760 },
];

export const CATEGORY_PLAYS: CategoryPlay[] = [
  { label: 'Music', value: 1240, color: COLORS.leaf },
  { label: 'Masti', value: 890, color: COLORS.blue },
  { label: 'Buzz', value: 430, color: COLORS.navy },
  { label: 'Gyaan', value: 380, color: COLORS.forest },
  { label: 'Career', value: 310, color: COLORS.leaf },
  { label: 'Talk', value: 290, color: COLORS.blue },
];

export const INITIAL_REQUESTS: SongRequest[] = [
  { id: 1, song: 'Kesariya', by: 'Arijit Singh', from: 'Ishaan, 2nd yr CSE', status: 'pending' },
  { id: 2, song: 'Apna Bana Le', by: 'Arijit Singh', from: 'Meher, Design', status: 'pending' },
  { id: 3, song: 'Chaiyya Chaiyya', by: 'Sukhwinder Singh', from: 'Rohan, Mech', status: 'pending' },
];

export const INITIAL_COMMENTS: Comment[] = [
  { id: 1, program: 'Campus Masti Episode 12', author: 'Zara', text: 'RJ Ananya is hilarious 😂', status: 'pending' },
  { id: 2, program: 'Exam Tips with Toppers', author: 'Devansh', text: 'This actually helped, thank you!', status: 'pending' },
];

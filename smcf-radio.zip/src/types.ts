export interface Category {
  slug: string;
  en: string;
  hi: string;
  icon: string;
  color: string;
}

export interface RJ {
  name: string;
  alias: string;
  dept: string;
  bio: string;
  color: string;
  initials: string;
}

export interface Program {
  id: number;
  title: string;
  titleHi: string;
  desc: string;
  cat: string;
  lang: string;
  rj: string;
  plays: number;
  duration: string;
  featured: boolean;
}

export interface ScheduleItem {
  time: string;
  title: string;
  rj: string;
  status: 'done' | 'live' | 'next';
}

export interface Announcement {
  en: string;
  hi: string;
}

export interface WeeklyPlay {
  day: string;
  plays: number;
}

export interface CategoryPlay {
  label: string;
  value: number;
  color: string;
}

export interface SongRequest {
  id: number;
  song: string;
  by: string;
  from: string;
  status: 'pending' | 'queued' | 'dismissed';
}

export interface Comment {
  id: number;
  program: string;
  author: string;
  text: string;
  status: 'pending' | 'approved' | 'removed';
}

export interface UserComment {
  author: string;
  text: string;
}
